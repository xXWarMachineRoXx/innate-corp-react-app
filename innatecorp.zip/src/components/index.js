export {default as Analytics} from './Analytics/analytics'
export {default as Brand} from './brand/brand'
export {default as UX} from './UX/UX'
export {default as Navbar} from './navbar/navbar'
export {default as FooterFrom} from './FooterForm/FooterForm'





