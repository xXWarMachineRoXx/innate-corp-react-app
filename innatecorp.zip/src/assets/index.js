export {default as analytics} from './Header Files/zip/analytics.svg'
export {default as Brand} from './Header Files/zip/brand.svg'
export {default as Sales} from './Header Files/zip/online Sales.svg'
export {default as UX} from './Header Files/zip/UX.svg'
